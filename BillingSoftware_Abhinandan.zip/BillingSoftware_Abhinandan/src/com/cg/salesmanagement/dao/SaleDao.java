package com.cg.salesmanagement.dao;


import java.util.HashMap;
import java.util.Random;

import com.cg.salesmanagement.bean.Sale;
import com.cg.salesmanagement.util.CollectionUtil;


public class SaleDao implements ISaleDao {

    @Override
    public Sale insertSalesDetails(Sale sale) {
        sale.setSaleId((int)(Math.random()*1000));
        if(sale.getProdCode()==1001) {
            sale.setCategory("Electronics");
            sale.setProductName("TV");
            sale.setPrice(35000);
            sale.setLineTotal(sale.getPrice()*sale.getQuantity());

        }
        else if(sale.getProdCode()==1002) {
            sale.setCategory("Electronics");
            sale.setProductName("Smart phone");
            sale.setPrice(30000);
            sale.setLineTotal(sale.getPrice()*sale.getQuantity());
        }
        else if(sale.getProdCode()==1003) {
            sale.setCategory("Electronics");
            sale.setProductName("Video Game");
            sale.setPrice(8000);
            sale.setLineTotal(sale.getPrice()*sale.getQuantity());
        }
        else if(sale.getProdCode()==1004) {
            sale.setCategory("toys");
            sale.setProductName("Soft toy");
            sale.setPrice(5000);
            sale.setLineTotal(sale.getPrice()*sale.getQuantity());
        }
        else if(sale.getProdCode()==1005) {
            sale.setCategory("toys");
            sale.setProductName("telescope");
            sale.setPrice(5000);
            sale.setLineTotal(sale.getPrice()*sale.getQuantity());
        }
        if(sale.getProdCode()==1006) {
            sale.setCategory("toys");
            sale.setProductName("Barbie doll");
            sale.setPrice(3000);
            sale.setLineTotal(sale.getPrice()*sale.getQuantity());
        }

        CollectionUtil.getCollection().put((int) sale.getSaleId(), sale);
        return sale;
    }

    @Override
    public Sale findOne(Sale sale) {

        return CollectionUtil.getCollection().get(sale.getSaleId());
    }


}

