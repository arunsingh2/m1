package com.cg.salesmanagement.Exception;

public class ValidProductCategoriesExceptions extends RuntimeException{

	public ValidProductCategoriesExceptions() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ValidProductCategoriesExceptions(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ValidProductCategoriesExceptions(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ValidProductCategoriesExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ValidProductCategoriesExceptions(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

}
