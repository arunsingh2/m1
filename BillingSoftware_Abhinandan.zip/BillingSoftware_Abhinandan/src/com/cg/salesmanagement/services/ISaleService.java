package com.cg.salesmanagement.services;
import java.time.LocalDate;
import java.util.HashMap;

import com.cg.salesmanagement.Exception.ValidProductCategoriesExceptions;
import com.cg.salesmanagement.Exception.ValidProductCodeException;
import com.cg.salesmanagement.Exception.ValidProductPriceException;
import com.cg.salesmanagement.Exception.ValidQuantityEnteredException;
import com.cg.salesmanagement.bean.Sale;
public interface ISaleService {

public boolean validateProductCode(int productId)throws  ValidProductCodeException;
boolean validateQuantity(int qty)throws ValidQuantityEnteredException;
public boolean validateProductCat(String prodCat)throws ValidProductCategoriesExceptions;
public boolean validateProductName(String prodName);
public boolean validateProductPrice(float Price)throws ValidProductPriceException;

public Sale insertSalesDetails(Sale sale);



}
